$(function () {

    var contactList = [];
    var contactListElement = $('#contactList');
    var contactForm = new contactFormClass();

    function initContactList() {
        contactList = [
            { 'id': 1, 'name': 'Louis', 'surname': 'Louis IIfasdf', 'phone': '894853409', 'email': 'dsfsdf@mailr.ru' },
            { 'id': 2, 'name': 'Louis', 'surname': 'Suares', 'phone': '345435454', 'email': 'jhkjhkj@mailr.ru' },
            { 'id': 3, 'name': 'Louis', 'surname': 'Brown', 'phone': '34235454656778', 'email': 'sjask@mailr.ru' },
            { 'id': 4, 'name': 'Louis', 'surname': 'Doe', 'phone': '89783231212', 'email': 'asdsad@mailr.ru' },
            { 'id': 5, 'name': 'Louis', 'surname': 'Black', 'phone': '632312312312', 'email': 'dfhjhjh@mailr.ru' },
            { 'id': 6, 'name': 'Louis', 'surname': 'Blue', 'phone': '89447798853409', 'email': 'nmcvcvzc@mailr.ru' },
            { 'id': 7, 'name': 'Louis', 'surname': 'White', 'phone': '32321243543', 'email': 'sjaxccxvvbvcbsk@mailr.ru' },
            { 'id': 8, 'name': 'Louis', 'surname': 'Purple', 'phone': '32131246776978078', 'email': 'szxczxczxjask@mailr.ru' },
            { 'id': 9, 'name': 'Louis', 'surname': 'Green', 'phone': '23167878767465', 'email': 'xcvcxbvx@mailr.ru' },
            { 'id': 10, 'name': 'Louis', 'surname': 'Benq', 'phone': '2435547679879', 'email': 'cxzvxcbnbv@mailr.ru' },
            { 'id': 11, 'name': 'Louis', 'surname': 'Asus', 'phone': '346568678967', 'email': 'vzcxzbvx@mailr.ru' },
            { 'id': 12, 'name': 'Louis', 'surname': 'Louis', 'phone': '432144657658', 'email': 'czxbxvbcv@mailr.ru' }
        ];
 

        for (var i = 0; i < contactList.length; i++) {
            appendContact(contactList[i]);
        }

        contactListElement.find('li:first').addClass('active');
        renderContact(contactList[0]);
    };

    initContactList();

    function appendContact(contact, isActive) {
        var element = $('<li data-id="' + contact.id + '" >' + contact.name + ' ' + contact.surname + '</li>');
        if (isActive) {
            contactListElement.find('li').removeClass('active');
            element.addClass('active');
        }
        element.on({
            'click': function () {
                renderContact(contact);
                contactListElement.find('li').removeClass('active');
                $(this).addClass('active');
            }
        });
        contactListElement.append(element);
    }

    function updateContact(contact) {
        var contactItem = contactListElement.find('li[data-id=' + contact.id + ']').text(contact.name + ' ' + contact.surname);
        var index = findContactIndexById(contact.id);
        contactList[index] = contact;
    }


    function renderContact(contact) {
        var personInfo = $('#person');
        var name = $('.jsPersonName', personInfo);
        var phone = $('.jsPersonPhone', personInfo);
        var email = $('.jsPersonEmail', personInfo);

        name.text(contact.name + ' ' + contact.surname);
        phone.text(contact.phone);
        email.text(contact.email);
    }

	var isValidate = false;
	function validateForm() {
	   	var validateForm = $('.jsValidateForm');
		var valiadateInput = validateForm.find('input[data-required=required]');

		valiadateInput.each(function(){
			var thisInput = $(this);
			var thisParent = thisInput.parent('.b-input-i');
			if (thisInput.val() == '') {
				thisParent.addClass('b-input-i_error');
				thisInput.addClass('error');
			} else {
				thisParent.removeClass('b-input-i_error');
				thisInput.removeClass('error');
			}
		});

		if (valiadateInput.hasClass('error')) {
			isValidate = false;
		} else {
			isValidate = true;
		}
		return isValidate;
	}

    function findContactIndexById(id) {
        for (var i = 0; i < contactList.length; i++) {
            if (contactList[i].id == id) {
                return i;
            }    
        }
    };

    function findContactById(id) {
        for (var i = 0; i < contactList.length; i++) {
            if (contactList[i].id == id) {
                return contactList[i];
            }
        }
    };

	function searchContact(searchText) {
		for (var i = 0; i < contactList.length; i++) {
			var searchTarget = contactList[i].name + ' ' + contactList[i].surname;
			if (searchTarget.toLowerCase() === searchText.toLowerCase()) {
				contactListElement.find('li[data-id=' + contactList[i].id + ']').click() ;
				return true;
			}
		}
	};

    function getSelectedContact () {
        return contactListElement.find('.active');
    };


	function clearSearch() {
		var search = $('.adressbook__search');
		var searchInput = $('.b-input', search);
		var searchInputWrap = $('.b-input-i', search);
		searchInput.click(function(){
			searchInputWrap.removeClass('no-result');
		})
	};
	clearSearch();


    $('.jsSaveBtn').click(function (e) {
        e.preventDefault();
        /*serializeArray()*/
        var contact = contactForm.getContact();

		validateForm();
		if (isValidate) {
			if (contact.id) {
				updateContact(contact);
			} else {
				var newId = contactList.length ? contactList[contactList.length - 1].id + 1 : 0;
				contact.id = newId;
				contactList.push(contact);
				appendContact(contact, true);
			}
			renderContact(contact);
			contactForm.reset();
			$('.jsAdressbook').removeClass('edit-open');
		} else {

		}
    });


    $(".jsAddBtn").click(function (e) {
        e.preventDefault();
		$('.jsAdressbook').addClass('edit-open')
    });

    $(".jsEditBtn").click(function (e) {
        var selected = getSelectedContact();
        var id = selected.attr('data-id');
        var contact = findContactById(id);
        contactForm.setContact(contact);
        e.preventDefault();
		$('.jsAdressbook').addClass('edit-open');
    });

    $(".jsRemoveBtn").click(function(e) {
        var selected = getSelectedContact();
        var id = selected.attr('data-id');
        var index = findContactIndexById(id);
        contactList.splice(index, 1);
       
        var next = selected.next('li');
       
        if (next.length > 0) {
            next.click();
        } else {
            var prev = selected.prev('li');
            if (prev.length > 0) {
                prev.click();
            } else {
                renderContact({ 'id': '', 'name': '', 'surname': '', 'phone': '', 'email': '' });
            }
        }
        selected.remove();
		$('.jsAdressbook').removeClass('edit-open');
        e.preventDefault();
    });

	$(".jsBtnSearch").click(function(e) {
		e.preventDefault();
		$(this).parent().removeClass('no-result');
		var searchInputText = $(this).siblings('.b-input').val();
//		searchInputText.removeClass('no-result');
		if (searchInputText != '') {
			searchContact(searchInputText);
		} else {
			return false;
		}
		if (searchContact(searchInputText)) {
		} else {
			$(this).parent().addClass('no-result');
		}
		$('.jsAdressbook').removeClass('edit-open');
	});

	$('.jsFormAddClose').click(function(e){
		e.preventDefault();
		$('.b-input-i').removeClass('b-input-i_error');
		$('.jsAdressbook').removeClass('edit-open');
		contactForm.reset();
	});

});



var contactFormClass = function () {
    var form = $('.jsForm');
    var name = $('.jsName', '.jsForm');
    var surname = $('.jsSurname', '.jsForm');
    var phone = $('.jsPhone', '.jsForm');
    var email = $('.jsEmail', '.jsForm');
    var id = $('.jsId', '.jsForm');

    return {
        setContact: setContact,
        getContact: getContact,
        reset: reset
    }

    function setContact(contact) {
        name.val(contact.name);
        surname.val(contact.surname);
        phone.val(contact.phone);
        email.val(contact.email);
        id.val(contact.id);
    }

    function getContact(contact) {
        return {'id': id.val(), 'name': name.val(), 'surname': surname.val(), 'phone': phone.val(), 'email': email.val() };
    }

    function reset() {
        $('input[type="text"],input[type="hidden"]', form).val('');
    }

}
