﻿(function() {
    function adressbookClass() {

        var contactsList = [];


    }
})();